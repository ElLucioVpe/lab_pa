#ifndef DTRESERVA_H
#define DTRESERVA_H

//No hace fata este DT
class DtReserva {
public:
    DtReserva(int, int);
    int getId() const;
    int getCantidadAsientos() const;
    
    virtual ~DtReserva();
private:
    int id;
    int cantidadAsientos;
};

#endif /* DTRESERVA_H */

