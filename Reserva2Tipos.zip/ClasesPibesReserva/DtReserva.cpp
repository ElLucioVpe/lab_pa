//Include del header

DtReserva::DtReserva(int id, int cantAsientos ){
    this->id = id;
    this->cantidadAsientos = cantAsientos;
}

int DtReserva::getId() const {
    return this->id;
}

int DtReserva::getCantidadAsientos() const {
    return this->cantidadAsientos;
}

DtReserva::~DtReserva() {
}
