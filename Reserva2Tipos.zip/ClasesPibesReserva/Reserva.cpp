//INCLUDE HEADER

Reserva::Reserva(int id, int cantAsientos ){
    this->id = id;
    this->cantidadAsientos = cantAsientos;
}

int Reserva::getId() const {
    return this->id;
}

int Reserva::getCantidadAsientos() const {
    return this->cantidadAsientos;
}

Reserva::~Reserva() {
}

