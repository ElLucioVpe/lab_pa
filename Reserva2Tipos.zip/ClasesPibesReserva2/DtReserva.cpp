//Include del header

DtReserva::DtReserva(float prec, int cantAsientos ){
    this->precio = prec;
    this->cantidadAsientos = cantAsientos;
}

int DtReserva::getPrecio() const {
    return this->precio;
}

int DtReserva::getCantidadAsientos() const {
    return this->cantidadAsientos;
}

DtReserva::~DtReserva() {
}
