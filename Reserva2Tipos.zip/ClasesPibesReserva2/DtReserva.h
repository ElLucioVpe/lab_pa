#ifndef DTRESERVA_H
#define DTRESERVA_H

//No hace fata este DT
class DtReserva {
public:
    DtReserva(float, int);
    float getPrecio() const;
    int getCantidadAsientos() const;
    
    virtual ~DtReserva();
private:
    float precio;
    int cantidadAsientos;
};

#endif /* DTRESERVA_H */

